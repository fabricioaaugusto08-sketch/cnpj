package br.com.texto.cnpj

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
