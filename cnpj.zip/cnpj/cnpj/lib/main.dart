//biblioteca para trabalhar com JSON
import 'dart:convert';

//biblioteca principal do Flutter - criar interface
import 'package:flutter/material.dart';

//biblioteca para fazer requisições HTTP para API
import 'package:http/http.dart' as http;

void main() {
  runApp(const MaterialApp(
    home: Cnpj(),
  ));
}

//StatefulWidget permite mudar a tela
class Cnpj extends StatefulWidget {
  const Cnpj({super.key});

  @override
  State<Cnpj> createState() => _CnpjState();
}

class _CnpjState extends State<Cnpj> {

  //começa vazio - não foi feita consulta
  final cnpj = TextEditingController();
  String endereco = '';

  // funão responsável por cunsultar a API
  consultar() async {
    final url = Uri.parse(
      //https://api.opencnpj.org/${cnpj.text}
      'https://api.opencnpj.org/${cnpj.text}',
    );

    // await - aguarda a resposta da API
    final resposta = await http.get(url);

    // jsonDecode transforma a o json em dados
    final dados = jsonDecode(resposta.body);

    // setState avisa o Flutter - os dados mudaram, atualize a tela
    setState(() {
      
      endereco =
          '${dados['razao_social']}\n'
          '${dados['nome_fantasia']}\n'
          '${dados['situacao_cadastral']} - ${dados['uf']}';
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Consulta CNPJ'),
      ),

      body: Padding(
        padding: const EdgeInsets.all(20),
        

        child: Column(
          children: [

            const Icon(
              Icons.location_on,
              size: 100,
            ),

            const SizedBox(height: 30),

            TextField(
              controller: cnpj,
              decoration: const InputDecoration(
                labelText: 'CNPJ',
                border: OutlineInputBorder(),
              ),
            ),

            const SizedBox(height: 20),

            ElevatedButton(
              onPressed: consultar,
              child: const Text('Consultar'),
            ),

            const SizedBox(height: 30),

            Text(
              endereco,
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}